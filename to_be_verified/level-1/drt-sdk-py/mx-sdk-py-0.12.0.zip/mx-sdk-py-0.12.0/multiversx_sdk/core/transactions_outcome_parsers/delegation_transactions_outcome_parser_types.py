from dataclasses import dataclass


@dataclass
class CreateNewDelegationContractOutcome:
    contract_address: str
