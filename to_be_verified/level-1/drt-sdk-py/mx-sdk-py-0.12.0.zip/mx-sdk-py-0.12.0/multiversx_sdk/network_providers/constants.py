from multiversx_sdk.core.address import Address

ESDT_CONTRACT_ADDRESS = Address.new_from_bech32("erd1qqqqqqqqqqqqqqqpqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqzllls8a5w6u")
METACHAIN_ID = 4294967295
MAX_UINT64 = 18446744073709551615
DEFAULT_ADDRESS_HRP = "erd"
