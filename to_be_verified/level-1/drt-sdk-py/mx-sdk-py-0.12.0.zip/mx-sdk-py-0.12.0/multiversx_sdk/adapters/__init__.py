from multiversx_sdk.adapters.query_runner_adapter import QueryRunnerAdapter

__all__ = ["QueryRunnerAdapter"]
