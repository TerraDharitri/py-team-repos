[![No Maintenance Intended](http://unmaintained.tech/badge.svg)](http://unmaintained.tech/)

This project is deprecated. All the functionality has been moved to the new [repository](https://github.com/multiversx/mx-sdk-py).

The migration guide as a GitHub issue can be found [here](https://github.com/multiversx/mx-sdk-py/issues/41).
